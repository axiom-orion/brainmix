/* app.jsx — top-level BrainMix Studio assembly + Tweaks */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": ["#00ffcc", "#a78bfa"],
  "ambience": "glow",
  "lcdColor": "mint",
  "spinSpeed": 6,
  "showManual": true,
  "deckCount": 2,
  "showBeatGrid": true,
  "showAnnotations": false
}/*EDITMODE-END*/;

const PALETTES = [
  ["#00ffcc", "#a78bfa"], // mint + violet (default)
  ["#ff7a00", "#22d3ee"], // sunset + cyan
  ["#ef4444", "#fbbf24"], // red + amber — danger deck
  ["#38bdf8", "#f472b6"], // electric blue + pink — bubblegum
  ["#a3e635", "#d946ef"], // lime + magenta — club
];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = React.useState("Studio");
  const [crossfader, setCrossfader] = React.useState(0.42);
  const [activePreset, setActivePreset] = React.useState("deskflow");
  const [recording, setRecording] = React.useState(false);
  const [recordElapsed, setRecordElapsed] = React.useState(0);
  const [playingA, setPlayingA] = React.useState(true);
  const [playingB, setPlayingB] = React.useState(false);

  // Apply tweaks live as CSS custom properties on :root
  React.useEffect(() => {
    const r = document.documentElement;
    const [a, b] = t.palette;
    r.style.setProperty("--mint", a);
    r.style.setProperty("--violet", b);
    // Recompute alpha tints from the chosen accents
    r.style.setProperty("--mint-bright", a);
    r.style.setProperty("--mint-05", hexAlpha(a, 0.05));
    r.style.setProperty("--mint-10", hexAlpha(a, 0.10));
    r.style.setProperty("--mint-20", hexAlpha(a, 0.20));
    r.style.setProperty("--mint-40", hexAlpha(a, 0.40));
    r.style.setProperty("--mint-66", hexAlpha(a, 0.66));
    r.style.setProperty("--violet-05", hexAlpha(b, 0.05));
    r.style.setProperty("--violet-10", hexAlpha(b, 0.10));
    r.style.setProperty("--violet-40", hexAlpha(b, 0.40));
    r.style.setProperty("--violet-66", hexAlpha(b, 0.66));

    // Jog wheel spin speed → CSS variable
    const dur = t.spinSpeed === 0 ? "0s" : (Math.max(0.5, 18 / t.spinSpeed)) + "s";
    r.style.setProperty("--spin-dur", dur);

    // LCD glow color
    const lcd = t.lcdColor === "amber" ? "#fbbf24"
              : t.lcdColor === "ice"   ? "#7dd3fc"
              : a; // mint = follow accent
    r.style.setProperty("--lcd", lcd);
  }, [t.palette, t.spinSpeed, t.lcdColor]);

  React.useEffect(() => {
    if (!recording) return;
    const id = setInterval(() => setRecordElapsed((x) => x + 1), 1000);
    return () => clearInterval(id);
  }, [recording]);

  const trackA = {
    title: "Cumbia Sobre El Mar — Quantic Remix",
    sub: "Quantic & Nidia Góngora · The Curao Sessions",
    bpm: 82, tempo: "1.04x", key: "F♯m", cue: "00:32",
    position: 134, duration: 318,
    eqLow: 2.5, eqMid: -1.5, eqHigh: 3.0,
    filterHz: 22050, loopOn: false, loopStart: "02:14",
    hotCues: ["00:00", "00:32", "01:04", "02:12", "03:08", null, null, null],
  };
  const trackB = {
    title: "Frio en el Alma — Bareto Edit",
    sub: "Bareto · Cumbia · 4:32",
    bpm: 94, tempo: "0.87x", key: "A♭m", cue: "00:48",
    position: 48, duration: 272,
    eqLow: -2.0, eqMid: 0, eqHigh: 1.5,
    filterHz: 4200, loopOn: true, loopStart: "00:48",
    hotCues: ["00:00", "00:48", null, null, null, null, null, null],
  };

  function togglePlay(side) {
    if (side === "a") setPlayingA((v) => !v);
    else setPlayingB((v) => !v);
  }

  const ambienceClass = "amb-" + t.ambience;
  const consoleStyle = t.deckCount === 1
    ? { gridTemplateColumns: "1fr 420px" }
    : {};

  return (
    <div className={"app " + ambienceClass + (t.showBeatGrid ? "" : " no-grid") + (t.showAnnotations ? " show-anno" : "")}>
      <TopBar view={view} onView={setView} />

      <main className="console" style={consoleStyle}>
        <DeckPanel
          side="a"
          spinning={playingA && t.spinSpeed > 0}
          onTogglePlay={() => togglePlay("a")}
          track={trackA}
          annotate={t.showAnnotations}
        />
        <MixerColumn
          crossfader={crossfader}
          onCrossfader={setCrossfader}
          activePreset={activePreset}
          onPreset={setActivePreset}
          beatHz={14.0}
          carrierHz={200}
          bpmSync={80}
          recording={recording}
          recordElapsed={recordElapsed}
          onToggleRecord={() => {
            setRecording((r) => !r);
            if (recording) setRecordElapsed(0);
          }}
          annotate={t.showAnnotations}
        />
        {t.deckCount === 2 && (
          <DeckPanel
            side="b"
            spinning={playingB && t.spinSpeed > 0}
            onTogglePlay={() => togglePlay("b")}
            track={trackB}
            annotate={t.showAnnotations}
          />
        )}
      </main>

      {t.showManual && <Manual />}

      <NowPlayingRail
        trackA={trackA}
        trackB={trackB}
        crossfader={crossfader}
        playingA={playingA}
        playingB={playingB}
        onTogglePlay={togglePlay}
      />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Look" />
        <TweakColor
          label="Accent palette"
          value={t.palette}
          options={PALETTES}
          onChange={(v) => setTweak("palette", v)}
        />
        <TweakRadio
          label="LCD glow"
          value={t.lcdColor}
          options={["mint", "amber", "ice"]}
          onChange={(v) => setTweak("lcdColor", v)}
        />
        <TweakSelect
          label="Background"
          value={t.ambience}
          options={[
            { value: "none",  label: "Pure black" },
            { value: "glow",  label: "Corner glow" },
            { value: "grid",  label: "Faint grid" },
            { value: "scan",  label: "CRT scanlines" },
          ]}
          onChange={(v) => setTweak("ambience", v)}
        />

        <TweakSection label="Decks" />
        <TweakRadio
          label="Deck count"
          value={t.deckCount}
          options={[
            { value: 1, label: "A only" },
            { value: 2, label: "A + B" },
          ]}
          onChange={(v) => setTweak("deckCount", v)}
        />
        <TweakSlider
          label="Jog spin"
          value={t.spinSpeed}
          min={0} max={12} step={1}
          unit=" rpm"
          onChange={(v) => setTweak("spinSpeed", v)}
        />
        <TweakToggle
          label="Show beat grid"
          value={t.showBeatGrid}
          onChange={(v) => setTweak("showBeatGrid", v)}
        />

        <TweakSection label="Layout" />
        <TweakToggle
          label="Show manual"
          value={t.showManual}
          onChange={(v) => setTweak("showManual", v)}
        />
        <TweakToggle
          label="Show annotations"
          value={t.showAnnotations}
          onChange={(v) => setTweak("showAnnotations", v)}
        />
      </TweaksPanel>
    </div>
  );
}

/* ---- hex#RRGGBB + alpha 0..1 → rgba() ---- */
function hexAlpha(hex, a) {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
