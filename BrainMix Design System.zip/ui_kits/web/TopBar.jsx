/* TopBar.jsx — header strip with brand + view tabs + sign-in */

function TopBar({ view, onView }) {
  return (
    <header className="topbar">
      <div className="brand">
        <img src={(typeof window !== "undefined" && window.__resources && window.__resources.logo) || "../../assets/logo-mark.svg"} alt="" />
        <div>
          <div className="wm">Brain<span className="accent">Mix</span></div>
          <div className="tag">Neuro-Acoustic Matrix · DJ Studio</div>
        </div>
      </div>

      <div className="views" role="tablist">
        {["Studio", "Music", "Timer"].map((v) => (
          <button
            key={v}
            role="tab"
            aria-selected={view === v}
            className={view === v ? "act" : ""}
            onClick={() => onView(v)}
          >
            {v}
          </button>
        ))}
      </div>

      <div className="actions">
        <button className="pill">Library · 142</button>
        <button className="pill">☁ My Mixes</button>
        <button className="signin">Sign in</button>
      </div>
    </header>
  );
}

window.TopBar = TopBar;
