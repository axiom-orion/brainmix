/* MixerColumn.jsx — central column with LCD, crossfader, master knobs, presets, record */

const PRESETS = [
  { id: "deskflow", emoji: "⚡", name: "Desk Flow",   hz: "14 Hz · 80 BPM",  ev: "strong" },
  { id: "poolside", emoji: "🌴", name: "Poolside",    hz: "8 Hz · 85 BPM",   ev: "mixed" },
  { id: "archaic",  emoji: "🌑", name: "Archaic",     hz: "7 Hz · EMDR",     ev: "mixed" },
  { id: "theta",    emoji: "🧘", name: "Theta",       hz: "6 Hz · breath",   ev: "mixed" },
  { id: "sleep",    emoji: "🌙", name: "Sleep",       hz: "2 Hz · delta",    ev: "mixed" },
  { id: "energy",   emoji: "🔥", name: "Energy",      hz: "18 Hz · 95 BPM",  ev: "vibes" },
];

function MixerColumn({
  crossfader,         // 0..1
  onCrossfader,
  activePreset,
  onPreset,
  beatHz,
  carrierHz,
  bpmSync,
  recording,
  recordElapsed,
  onToggleRecord,
}) {
  // crossfader visual fill from A side
  const xfPct = (1 - crossfader) * 100;
  const knobLeft = `calc(${crossfader * 100}% - 18px)`;

  return (
    <aside className="mixer">
      {/* LCD readout */}
      <div className="lcd">
        <div className="l">Matrix · entrainment</div>
        <div className="big">{beatHz.toFixed(2)} Hz</div>
        <div className="row">
          <span>carrier <span className="v">{carrierHz}</span></span>
          <span>{bpmSync > 0 ? <>gate <span className="v">{bpmSync} BPM</span></> : <>gate <span className="v">off</span></>}</span>
        </div>
      </div>

      {/* Crossfader */}
      <div className="xf-wrap">
        <div className="xf-top">
          <span className="a">A</span>
          <span className="mid">Crossfader · {crossfader.toFixed(2)}</span>
          <span className="b">B</span>
        </div>
        <div className="xf-rail">
          <div className="channel" />
          <div className="fill-a" style={{ width: xfPct + "%" }} />
          <div
            className="knob"
            style={{ left: knobLeft }}
            onMouseDown={(e) => startDrag(e, onCrossfader)}
          />
        </div>
        <div style={{ textAlign: "center", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.16em", color: "var(--fg-5)" }}>
          equal-power · 6s auto x-fade
        </div>
      </div>

      {/* Master knob row */}
      <div className="knobs">
        <Knob name="Gain" val="0.62" rot={45} />
        <Knob name="Mix" val="50%" rot={-30} />
        <Knob name="Drone" val="0.18" rot={90} />
        <Knob name="Noise" val="brown" rot={-60} />
      </div>

      {/* Preset row */}
      <div className="preset-row">
        <div className="label">Brainwave preset · 6 options</div>
        <div className="grid">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              className={"pcard" + (p.id === activePreset ? " act" : "")}
              onClick={() => onPreset(p.id)}
            >
              <div className="emoji">{p.emoji}</div>
              <div className="name">{p.name}</div>
              <div className="hz">{p.hz}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Record row */}
      <div className={"rec-row" + (recording ? " live" : "")}>
        <span className="dot" />
        <span className="label">{recording ? "Recording" : "Recorder"}</span>
        <span className="time">{formatTime(recordElapsed)}</span>
        <button onClick={onToggleRecord}>{recording ? "Stop" : "● Record"}</button>
      </div>
    </aside>
  );
}

function Knob({ name, val, rot }) {
  return (
    <div className="kstack">
      <div className="knob" style={{ "--rot": rot + "deg" }} />
      <div className="name">{name}</div>
      <div className="val">{val}</div>
    </div>
  );
}

/* Drag a horizontal value between 0 and 1, snapping the crossfader knob. */
function startDrag(e, onChange) {
  e.preventDefault();
  const rail = e.currentTarget.parentElement;
  const rect = rail.getBoundingClientRect();
  const move = (ev) => {
    const x = (ev.clientX - rect.left) / rect.width;
    onChange(Math.max(0, Math.min(1, x)));
  };
  const up = () => {
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
  };
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}

window.MixerColumn = MixerColumn;
window.PRESETS = PRESETS;
