/* NowPlayingRail.jsx — sticky bottom mini-player. */

function NowPlayingRail({ trackA, trackB, crossfader, playingA, playingB, onTogglePlay }) {
  // Whichever side is more open in the crossfader is "primary".
  const primary = crossfader < 0.5 ? "a" : "b";
  const track = primary === "a" ? trackA : trackB;
  const playing = primary === "a" ? playingA : playingB;
  const accent = primary === "a" ? "var(--mint)" : "var(--violet)";

  return (
    <div className="now-playing-rail">
      <div className="row">
        <div className="cover">♪</div>
        <div className="meta">
          <div className="title">{track.title}</div>
          <div className="sub" style={{ color: accent }}>
            {primary.toUpperCase()} · {track.bpm} BPM · {track.tempo}
          </div>
        </div>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ flex: 1, height: 4, background: "var(--surface-3)", borderRadius: 2, position: "relative", boxShadow: "inset 0 1px 2px rgba(0,0,0,.5)" }}>
            <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: ((track.position / track.duration) * 100) + "%", background: accent, borderRadius: 2 }} />
          </div>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-4)" }}>
            {formatTime(track.position)} / {formatTime(track.duration)}
          </span>
        </div>
        <div className="tp">
          <button>⏮</button>
          <button className="play" onClick={() => onTogglePlay(primary)}>{playing ? "❚❚" : "▶"}</button>
          <button>⏭</button>
        </div>
      </div>
    </div>
  );
}

window.NowPlayingRail = NowPlayingRail;
