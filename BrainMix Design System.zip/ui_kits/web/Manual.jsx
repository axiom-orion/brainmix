/* Manual.jsx — "full functionality explained" panel below the console.
   Four columns: Decks, Mixer, Matrix, Sessions. */

function Manual() {
  return (
    <section className="manual">
      <div className="group">
        <h4>① The turntables</h4>
        <p>Two independent decks. Load any file you own — MP3, M4A, WAV, FLAC, OGG. Stays on your device until you sign in.</p>
        <div className="step"><span className="n">A</span><span>Mint deck. Primary playback. Synced to the matrix BPM gate.</span></div>
        <div className="step"><span className="n">B</span><span>Violet deck. Beat-matched to A. Use for transitions, layering, mashups.</span></div>
        <div className="step"><span className="n">▶</span><span>Big play button starts the platter; the jog wheel spins. ❚❚ pauses.</span></div>
        <div className="step"><span className="n">⏯</span><span>Cue: jump to the last hot cue, hold to preview.</span></div>
        <div className="step"><span className="n">↻</span><span>Loop: re-trigger the current 4-bar segment from the in-point.</span></div>
      </div>

      <div className="group violet">
        <h4>② The mixer column</h4>
        <p>Everything that mixes the two decks together — and the brain-state layer too.</p>
        <div className="step"><span className="n">▮</span><span>Crossfader. Equal-power curve. Drag to mix A → B. Auto x-fade at 6s.</span></div>
        <div className="step"><span className="n">◯</span><span>Gain · Mix · Drone · Noise. Four master rotaries.</span></div>
        <div className="step"><span className="n">3-band</span><span>Per-deck low / mid / high cuts in dB. Double-click a band to zero it.</span></div>
        <div className="step"><span className="n">LPF</span><span>Low-pass filter sweep. Click "OPEN" to bypass entirely.</span></div>
        <div className="step"><span className="n">8 cue</span><span>Hot cues per deck. Tap empty to set, tap set to jump, × clears.</span></div>
      </div>

      <div className="group">
        <h4>③ The brain matrix</h4>
        <p>Layered binaural / isochronic tones that ride underneath the music. Six presets, one active at a time. Evidence-graded.</p>
        <div className="step"><span className="n">⚡</span><span><b>Desk Flow.</b> 40 Hz gamma boost · 14 Hz beat · 80 BPM gate. Strong evidence (MIT Tsai lab).</span></div>
        <div className="step"><span className="n">🌴</span><span><b>Poolside.</b> 8 Hz alpha · 85 BPM. Mixed evidence.</span></div>
        <div className="step"><span className="n">🌑</span><span><b>Archaic.</b> 110 Hz sub-bass · 7 Hz pulse · EMDR pan. Mixed evidence.</span></div>
        <div className="step"><span className="n">🔥</span><span><b>Energy.</b> 18 Hz mid-beta · 95 BPM. Vibes only — admitted.</span></div>
      </div>

      <div className="group rose">
        <h4>④ Sessions & recording</h4>
        <p>Run a Pomodoro plan that auto-swaps presets at intervals. Record everything you mix.</p>
        <div className="step"><span className="n">●</span><span>Hit Record to capture the master output as you mix. Stop saves it locally.</span></div>
        <div className="step"><span className="n">☁</span><span>Sign in to save mixes to the cloud and get a public share URL.</span></div>
        <div className="step"><span className="n">⌚</span><span>Sequencer: stack Focus / Rest steps, walk a plan automatically.</span></div>
        <div className="step"><span className="n">🩺</span><span>The Engineer panel surfaces tips: "mid clipping on A", "try a 4-bar loop at 02:14".</span></div>
      </div>
    </section>
  );
}

window.Manual = Manual;
