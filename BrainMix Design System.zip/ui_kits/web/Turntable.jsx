/* Turntable.jsx — spinning jog wheel with cue strobe + center hub */

function Turntable({ deck, spinning }) {
  return (
    <div className="jog-wrap">
      <div className={"jog" + (spinning ? "" : " paused")}>
        <div className="hub">{deck.toUpperCase()}</div>
      </div>
    </div>
  );
}

window.Turntable = Turntable;
