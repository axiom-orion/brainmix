/* DeckPanel.jsx — full deck column: turntable + meta + scrub + transport + stats + EQ + hot cues */

function DeckPanel({
  side,           // "a" or "b"
  spinning,
  onTogglePlay,
  track,          // { title, sub, bpm, tempo, key, position, duration, eqLow, eqMid, eqHigh, filterHz, hotCues }
}) {
  const isA = side === "a";
  const accentLabel = isA ? "Deck A · active" : "Deck B · cueing";
  const accentClass = isA ? "act-a" : "act-b";
  const playClass = isA ? "play-a" : "play-b";

  // Mini beat-grid ticks
  const ticks = [];
  for (let i = 1; i < 12; i++) ticks.push(i * 8.3);
  const pct = (track.position / track.duration) * 100;

  return (
    <div className={"deck " + side}>
      <div style={{ width: 320, display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span style={{
          fontSize: 10, textTransform: "uppercase", letterSpacing: "0.16em",
          color: isA ? "var(--mint)" : "var(--violet)",
        }}>{accentLabel}</span>
        <span style={{
          fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--fg-4)",
        }}>{spinning ? "▶ live" : "❚❚ paused"}</span>
      </div>

      <Turntable deck={side} spinning={spinning} />

      <div className="deck-meta">
        <div className="title">{track.title}</div>
        <div className="sub">{track.sub}</div>
      </div>

      <div className="deck-scrub">
        <div className="bar">
          <div className="fill" style={{ width: pct + "%" }} />
          <div className="ticks">{ticks.map((p, i) => (
            <div key={i} className="tk" style={{ left: p + "%" }} />
          ))}</div>
        </div>
        <div className="times">
          <span>{formatTime(track.position)}</span>
          <span>{formatTime(track.duration)}</span>
        </div>
      </div>

      <div className="deck-tp">
        <button className={"btn " + accentClass} aria-label="Hot cue prev">⏮</button>
        <button className={"btn " + accentClass} aria-label="Cue">⏯</button>
        <button className={"btn " + playClass} onClick={onTogglePlay} aria-label={spinning ? "Pause" : "Play"}>
          {spinning ? "❚❚" : "▶"}
        </button>
        <button className={"btn " + accentClass} aria-label="Loop">↻</button>
        <button className={"btn " + accentClass} aria-label="Hot cue next">⏭</button>
      </div>

      <div className="deck-stats">
        <div className="s"><div className="l">BPM</div><div className="v">{track.bpm}</div></div>
        <div className="s"><div className="l">Tempo</div><div className="v">{track.tempo}</div></div>
        <div className="s"><div className="l">Key</div><div className="v">{track.key}</div></div>
        <div className="s"><div className="l">Cue</div><div className="v">{track.cue}</div></div>
      </div>

      <div className="deck-eq">
        <div className="panel">
          <div className="head"><span className="name">EQ · 3-band</span><span className="v">{track.eqLow > 0 ? "+" : ""}{track.eqLow.toFixed(1)}/{track.eqMid > 0 ? "+" : ""}{track.eqMid.toFixed(1)}/{track.eqHigh > 0 ? "+" : ""}{track.eqHigh.toFixed(1)}</span></div>
          <div className="eq3">
            <EqBand label="Low" value={track.eqLow} />
            <EqBand label="Mid" value={track.eqMid} />
            <EqBand label="High" value={track.eqHigh} />
          </div>
        </div>
        <div className="panel">
          <div className="head"><span className="name">LPF · cutoff</span><span className="v">{track.filterHz >= 22000 ? "OPEN" : (track.filterHz + " Hz")}</span></div>
          <div style={{ height: 4, background: "var(--surface-3)", borderRadius: 2, marginTop: 2, position: "relative", boxShadow: "inset 0 1px 2px rgba(0,0,0,.5)" }}>
            <div style={{
              position: "absolute", left: 0, top: 0, bottom: 0,
              width: Math.min(100, (track.filterHz / 22050) * 100) + "%",
              background: isA ? "var(--mint)" : "var(--violet)",
              borderRadius: 2,
            }}/>
          </div>
          <div className="head" style={{ marginTop: 14 }}>
            <span className="name">Loop · 4 bar</span>
            <span className="v">{track.loopOn ? "ON @ " + track.loopStart : "off"}</span>
          </div>
        </div>
      </div>

      <div className="hot-cues">
        <div className="label">Hot cues · 8 slots · tap empty to set, tap set to jump</div>
        <div className="grid">
          {track.hotCues.map((c, i) => (
            <div key={i} className={"cell" + (c ? " set" : "")}>
              {c || (i + 1)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function EqBand({ label, value }) {
  // -15 to +15 dB, map to vertical position
  const isPos = value >= 0;
  const pct = Math.abs(value) / 15 * 50; // 50% max from center
  return (
    <div className="band">
      <div className="name">{label}</div>
      <div className="vert">
        <div className="vf" style={isPos
          ? { bottom: "50%", height: pct + "%" }
          : { top: "50%", height: pct + "%" }} />
        <div className="vt" style={{
          top: (isPos ? (50 - pct) : (50 + pct - 9)) + "%",
        }} />
      </div>
      <div className="val">{isPos ? "+" : ""}{value.toFixed(1)}</div>
    </div>
  );
}

function formatTime(sec) {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m.toString().padStart(2, "0") + ":" + r.toString().padStart(2, "0");
}

window.DeckPanel = DeckPanel;
window.formatTime = formatTime;
