# BrainMix Web · UI Kit

The flagship surface for BrainMix: a dual-turntable DJ console with the brainwave-entrainment matrix mixed in.

## Structure

- `index.html` — root. Boots React 18, loads Babel, includes all JSX files.
- `console.css` — layout + console-specific styles. Pulls tokens from `../../colors_and_type.css`.
- `app.jsx` — root component, holds the simulated state (crossfader, decks, presets, recording).
- `TopBar.jsx` — header with brand + Studio/Music/Timer tabs + library + sign-in.
- `Turntable.jsx` — spinning jog wheel with center hub letter (A / B).
- `DeckPanel.jsx` — full deck column: turntable, meta, scrub w/ beat grid, transport, BPM stats, 3-band EQ, LPF, 8 hot cues.
- `MixerColumn.jsx` — sticky center column: matrix LCD, crossfader, four master rotaries, six preset cards, record bar.
- `Manual.jsx` — "full functionality explained" reference panel below the console. Four columns: decks, mixer, matrix, sessions.
- `NowPlayingRail.jsx` — sticky bottom mini-player. The primary deck (per crossfader) is the one shown.

## Coverage vs. the real app

The real BrainMix is mobile-first single-column with horizontal sliders. This UI kit re-presents the same controls in a wide DJ-console layout (per the brief: "active DJ setup with turn tables, action buttons, and full functionality explained"). All controls and their behaviours map 1:1 to functionality in `brainmix/app/page.tsx` and `app/components/MixerSection.tsx`.

## How to extend

- Add a screen → new `.jsx` file, add a script tag in `index.html`, wire it into `App` in `app.jsx`.
- Add a control → add CSS in `console.css`, export the component to `window`, import where used.
- Keep numeric values in `var(--font-mono)` with `tabular-nums` — the design system depends on it.
