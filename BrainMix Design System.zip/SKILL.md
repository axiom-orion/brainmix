---
name: brainmix-design
description: Use this skill to generate well-branded interfaces and assets for BrainMix, either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. BrainMix is a layered brainwave-entrainment audio app with a real DJ studio — dark cyberpunk console aesthetic, mint + violet accents, Geist Sans/Mono.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference

- **Brand colors**: mint `#00ffcc` (Deck A, primary, focus) + violet `#a78bfa` (Deck B, rest). Page background is always `#09090b`. See `colors_and_type.css` for the full token list.
- **Type**: Geist Sans body, Geist Mono for every numeric value. Tabular nums.
- **Iconography**: Unicode glyphs only. No icon library. See README for the table.
- **Tone**: second-person, technical, honest, dry-funny. Evidence-graded copy.
- **Layout**: single narrow column, sticky now-playing widget at bottom, modal stack on top.

## Files

- `README.md` — full brand, content, visual foundations
- `colors_and_type.css` — drop-in CSS variables
- `assets/logo-mark.svg`, `assets/favicon.ico` — brand mark
- `preview/*.html` — design-system specimens for every component
- `ui_kits/web/` — React JSX UI kit; start with `index.html`
