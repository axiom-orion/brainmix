# BrainMix Design System

> The brand and component vocabulary of **BrainMix** — a layered brainwave-entrainment audio app with a real, working DJ studio. The interface is an active console: two turntables (Slot A in mint, Slot B in violet), a crossfader, EQ, hot cues, a recording bar, and a panel of presets that promise different brain states under your music.

The product lives at [brainmix](https://github.com/) (a Next.js 16 + Supabase web app, PWA-installable). This design system extracts the brand foundations so you can produce on-brand marketing, decks, prototypes, and new screens without re-deriving them.

---

## Sources

This design system was distilled from:

- **Codebase** — `brainmix/` (Next.js 16 + React 19 + Tailwind 4 + Supabase). Key files:
  - `app/layout.tsx` — fonts, metadata
  - `app/globals.css` — color tokens, slider styles
  - `app/page.tsx` — the entire app shell (2 468 lines, a single page)
  - `app/components/*` — MixerSection, NowPlayingWidget, MusicHub, EngineerCard, primitives, AcademyModal, LibraryModal, PlaylistsModal, SignInModal
  - `lib/presets.ts` — the six brainwave presets and their evidence levels
  - `lib/audioEngine.ts`, `bpmDetect.ts`, `djBus.ts` — the audio guts
  - `public/icon.svg` — brand mark
- No Figma was provided.
- No slide decks were provided.

---

## Index

| File | Purpose |
| --- | --- |
| `README.md` | This file. Brand, content, visual, iconography foundations. |
| `colors_and_type.css` | Drop-in CSS variables for color, type, spacing, radii, shadows, motion. |
| `SKILL.md` | Cross-compatible skill manifest for Claude Code / Agent Skills. |
| `assets/` | Logo mark (SVG) + favicon. |
| `preview/` | Per-card design-system specimens that populate the Design System tab. |
| `ui_kits/web/` | React JSX UI kit for the BrainMix web app — Studio, Music, Timer screens. |

---

## What BrainMix actually is

A web app that does two interlocked things:

1. **Brainwave-entrainment matrix.** Six presets (`Desk Flow`, `Poolside Chill`, `Archaic Reset`, `Meditative Theta`, `Sleep / Recovery`, `Energy Lift`), each defined by a carrier Hz, a beat Hz, a drone, a noise color, an LFO shape, an entrainment mode (binaural / isochronic), and an optional BPM gate. Each preset is tagged **strong / mixed / vibes** for evidence honesty.
2. **A real DJ studio.** Two song slots (A and B) with EQ, low-pass filter, tempo (pitch-preserving), 8 hot cues, beat-aware loops, a beat-grid overlay, a crossfader, and live recording with cloud sharing. The matrix entrainment layer mixes underneath the songs.

Plus: a Pomodoro session sequencer, an in-app rule-based "Engineer" that gives mix tips, an Academy of deep-dive science cards, and a library/playlists/mixes set of modal stacks (local IDB when signed out, Supabase cloud when signed in).

The single-page web app is the only product. There is no native app, marketing site, docs site, or design system Figma. Everything lives in `app/page.tsx` and its component split.

---

## CONTENT FUNDAMENTALS

BrainMix copy is **second-person, technical, honest, and dry-funny**. It assumes a reader who likes neuroscience and DJing equally.

### Tone & voice

- **Second person, imperative or descriptive.** "Drop audio anywhere on this page to import." "Lock-in for coding, writing, analytical work."
- **Authoritative but hedged when warranted.** Strong-evidence claims state facts ("40 Hz gamma is the only entrainment frequency with strong neuroscience"). Mixed-evidence claims name the study and the unreplicated status. Vibes claims openly admit they're vibes.
- **Dry, faintly amused.** "Hydrate, walk, sunlight." "Brown noise masks the auditory startle response." "Best driven by music you actually love — dopamine from anticipation > entrainment."
- **No marketing puff.** No "unlock your potential", no "revolutionary", no "AI-powered". The product is treated as a tool for a reader who knows what they want.
- **Plain Sentence case** for almost everything. UPPERCASE TRACKING-WIDER is reserved for eyebrow labels above values (BEAT HZ / 14 Hz). Title Case is reserved for proper preset names ("Desk Flow", "Poolside Chill") and modal titles.
- **No emoji in body copy.** The six preset emojis (⚡ 🌴 🌑 🧘 🌙 🔥) are the only emoji and they only appear on the preset cards. Nowhere else.
- **Em dashes** for asides ("Layer brain-state under the music — entrainment that hides inside the off-beats"). Middle dots (·) separate metadata tokens ("Quantic · The Curao Sessions"). Slashes for short alternatives ("MP3 / M4A / WAV").

### Vocabulary

- "**Matrix**" = the entrainment audio layer.
- "**Studio / The Mixer**" = the DJ surface. "Easy Mix" mode (one slot, big-buttons) and "Remix" mode (two slots, full controls).
- "**Deck A / Slot A / Deck B / Slot B**" — always paired with the mint/violet colors. Never call them "Track 1 / Track 2".
- "**The Engineer**" — the tip panel. It "notices", "suggests", "applies".
- "**The Academy**" — the deep-dive science library.
- "**Pomodoro**" — focus + rest cycles, not "session timer".
- Numbers use **Hz, BPM, dB, x (tempo), s, min, %**. Never spell out units.

### Microcopy examples

> Drop audio anywhere on this page to import. Stays on your device until you sign in to sync.

> Lock-in for coding, writing, analytical work. Designed to layer under reggae-rock at ~80 BPM.

> Brown noise masks the auditory startle response. Drone set low — lower fundamentals correlate with calming responses cross-culturally.

> 110 Hz vagal sub-bass with bilateral panning for hemisphere cross-talk. Single small study, never replicated. Body resonance does measurably drop heart rate via vagus stimulation. EMDR panning mimics bilateral stimulation used in trauma therapy.

> Quick-bar buttons need a BPM. Tap empty to set · tap set to jump · × clears.

> Session complete. Hydrate, walk, sunlight.

---

## VISUAL FOUNDATIONS

### Aesthetic, in one sentence

**A dark cyberpunk DJ console: zinc-on-black surfaces lit up by neon-mint and violet accent borders, with mono numeric readouts in tabular nums.** No drop shadows on most surfaces — the depth comes from accent-tinted borders and tinted backgrounds at 5–10% alpha. The page background never lightens; it's `#09090b` everywhere, like a real rack-mount unit.

### Color

- **Page background**: `#09090b` (zinc-950). Never lighter.
- **Two brand accents**: `#00ffcc` mint (primary, Deck A, focus, all "active" states) and `#a78bfa` violet (Deck B, rest phase, secondary deck). Always paired. The crossfader visually fades between them.
- **Rose** `#fb7185` — import, destructive, *and* the live-recording dot.
- **Evidence triad** — emerald `#34d399` (strong), amber `#fbbf24` (mixed), fuchsia `#e879f9` (vibes). The brand is honest about its claims; the color codes that honesty.
- **Surfaces** are pure grayscale (zinc 800/900/950) — accents never bleed into the surface itself except as `0.05` alpha tints.
- **Borders** are the workhorse — accent at `0.40` to `0.55` alpha is the dominant "active state" signal.

### Type

- **Geist** sans for everything that isn't a number.
- **Geist Mono** for every numeric value (BPM, Hz, dB, time, tempo scale, file sizes, share URLs). Always `tabular-nums`.
- Body type is small (12–14px); the readouts and the preset emojis carry the bigness. Headings use `font-weight: 300` and tight tracking.
- **The signature pattern**: a tiny uppercase eyebrow on the left (`fg-4`, `letter-spacing: 0.16em`) and a mono numeric readout on the right (accent-colored). Repeated maybe 80 times across the app.

### Backgrounds, gradients, imagery

- **No photography**, no illustration, no patterns. The console is an instrument; it would not have a hero photo.
- **Two background tricks only**:
  - The crossfader uses a `linear-gradient(90deg, var(--mint-05), var(--violet-05))` — the only horizontal gradient in the app.
  - The page itself can have two faint corner radial-gradients (mint top-left, violet bottom-right at ~5% alpha) on heavier screens. Almost imperceptible.
- **Cover art** for tracks is user-supplied (ID3 tags). When missing, a `♪` glyph on a `#16161a` plate.

### Borders, corners, depth

- **Three hairline widths in practice**: 1px solid for almost everything. Inset 1px on slider tracks. Dashed 1px for empty-state targets ("+ Add second song").
- **Corner radii** — five steps: 4px (sliders), 6px (small pills), 8px (inputs), 12px (cards), 16px (decks/modals). 9999px for transport buttons and the rec dot.
- **No drop shadow on most surfaces.** Only the sticky now-playing widget and modals get `0 8px 24px rgba(0,0,0,0.5)`. Sliders get an inset shadow on the track. Everything else uses accent glow: `0 0 0 1px rgba(0,255,204,0.4), 0 0 12px rgba(0,255,204,0.25)`.

### States

- **Hover**: surfaces lighten one zinc step (`bg-zinc-900/40 → bg-zinc-900`). Accent borders don't change; the fill behind them does.
- **Active / on**: border bumps from `var(--hairline)` to accent-at-40, background bumps from `surface-mute` to accent-at-05. The label colour switches from `fg-3` to the accent.
- **Press**: no scale change. Just a brief background tint flash.
- **Disabled**: opacity 0.3 or 0.4. No greyscaling.
- **Focus**: `border-color: var(--mint-40)`. No outline ring.

### Motion

- **Easings** — `cubic-bezier(0.2, 0.8, 0.2, 1)` is the default. The Pomodoro progress bar uses 500ms transitions; everything else 120–200ms.
- **The only loops** are the pulsing record dot (1.2s ease-in-out) and (in this design system, for showmanship) the spinning jog wheel. The real app does not spin the wheel.
- **Crossfade** = the brand's signature transition. Equal-power 6s when auto-crossfading queue items.
- **No bouncy springs, no parallax, no scroll-triggered reveals.** The console is calm; the music isn't.

### Transparency & blur

- **One sticky element uses backdrop blur**: the now-playing widget at the bottom of the screen, `backdrop-blur-md` over a `#16161a` at 95% opacity. Nothing else uses blur — the page sits on solid black.

### Layout rules

- **One narrow column** on mobile + desktop alike (the live app is mobile-first, ~440px column). Wider screens just centre the column. No multi-column dashboards.
- **The bottom of the viewport is reserved** for the sticky now-playing widget when audio is active. Pages add bottom padding to compensate.
- **A modal stack** sits on top — Library, Playlists, MyMixes, Academy, SignIn — never side-by-side panels.

### Cards & containers

- Standard card: `border: 1px solid var(--hairline)`, `background: rgba(24,24,27,0.30)`, `border-radius: 12px`, `padding: 14–16px`.
- Active-deck card: same but `border-color: var(--mint-40)` and `background: var(--mint-05)`.
- Empty-state target: `border: 1px dashed var(--accent-40)`, `background: var(--accent-05)`.

---

## ICONOGRAPHY

BrainMix does **not** ship an icon library. There is no Lucide, no Heroicons, no Font Awesome, no custom SVG sprite. **All icons in the app are Unicode characters** rendered in Geist Mono, tinted to the context.

| Glyph | Use |
| --- | --- |
| `▶` `❚❚` | play / pause (transport) |
| `⏮` `⏭` | prev / next (transport) |
| `⏯` | cue |
| `⇄` | shuffle / sync |
| `↻` | repeat / loop |
| `⤲` | crossfade |
| `●` (rose, pulsing) | recording |
| `↓` | download |
| `☁` | save to cloud |
| `⭑` | save (to library / favorite) |
| `+` `✕` | add / close |
| `?` | info popover trigger |
| `♪` | fallback cover art |
| `−` | collapse |

**Emoji** are used in **exactly one place**: the six brainwave preset cards (⚡ 🌴 🌑 🧘 🌙 🔥). They are not used in body copy, buttons, headings, or anywhere else. The brand mark in `assets/logo-mark.svg` is the only piece of SVG iconography.

When designing new surfaces, follow the same rule: pick a Unicode glyph that works at 11–14px in Geist Mono, tint it to the context, never combine with a label inside the same button (except transport which is glyph-only on purpose).

> **Caveat to the user:** the BrainMix codebase loads Geist via `next/font/google`. We import Geist + Geist Mono from Google Fonts CDN in `colors_and_type.css` for matching fidelity in this design system. The live app's font file is not exported here — that's a substitution. **Flag**: if you need pixel-perfect Geist for production, copy the font files from `node_modules/@vercel/font-geist` in the real repo and replace the `@import` line in `colors_and_type.css`.

---

## Notes & caveats

- The "active DJ setup with turntables" framing in this design system is **a re-skin** of how the real BrainMix shows itself. The live app uses horizontal sliders and progress bars; the design system adds a spinning jog wheel + LCD readout for showmanship in the preview cards and in `ui_kits/web/Turntable.jsx`. That component is opt-in.
- The real codebase uses **Tailwind** classes; this design system uses **CSS custom properties**. The two are aligned (every variable maps to a Tailwind class) but you'll see syntax differences if you compare the preview cards to `app/page.tsx`.
- All evidence claims, preset names, blurbs, and copy fragments quoted in cards come from `lib/presets.ts` and `app/page.tsx` verbatim or near-verbatim — do not invent new science copy without checking the real product first.
